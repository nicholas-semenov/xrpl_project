# Blend submission

Run v2 (`scripts/aml_model.py`) and v3 (README, 'Latest submission v3'), then:

```sh
.venv/bin/python scripts/blend.py outputs/blend_v2_v3/predictions.csv outputs/aml_two_stage_v2/predictions.csv outputs/aml_two_stage_v3/predictions.csv
```

Equal-weight rank average of the two models' test scores. Leaderboard: v2 66.1, v3 65.7; the blend has not been validated on train.
